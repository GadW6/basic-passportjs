# basic-passportjs

A base setup for passportjs library